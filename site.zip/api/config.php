<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'JyGl20FC3jc9zHFLp183HZnUz');
    define('CONSUMER_SECRET', 'QJI8ThSQx3hOcO1H1LubB6cAbpp8yvsKqNZ9SvEadcyUXaUYou');

    // User Access Token
    define('ACCESS_TOKEN', '2855394740-iZduf05658s6Y0EshW0DEmyEnFcR0i45f09D0vv');
    define('ACCESS_SECRET', 'AYK1DKQKUyEEvFSyvRDvHZ0FfG7dufuqTYcRc2btLQ8sr');